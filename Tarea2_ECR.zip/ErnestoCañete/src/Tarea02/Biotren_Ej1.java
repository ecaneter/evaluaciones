package Tarea02;

import java.util.Scanner;

import Farmacia.Producto;

public class Biotren_Ej1 {
	
	private static Scanner sc;
	static int ultimo=0;
	static int nro_t=123456789;
	static Tarjeta_Ej1 T[] = new Tarjeta_Ej1[3];

	public static void main(String[] args) throws InterruptedException {
		
		sc=new Scanner(System.in);
		int op;
		
		do {
			System.out.println(" ");
			System.out.println("*************** Menu **************");
			System.out.println("***** 1.- Crear usuario       *****");
			System.out.println("***** 2.- Abonar dinero       *****");
			System.out.println("***** 3.- Descuento por viaje *****");
			System.out.println("***** 4.- Consultar saldo     *****");
			System.out.println("***** 5.- Cambiar estado      *****");
			System.out.println("***** 0.- Hasta pronto.       *****");
			System.out.println("***********************************");
			System.out.println(" ");
			System.out.print("Ingrese una opcion: ");
			System.out.print(" ");
			op=sc.nextInt();
			
			switch(op) {
			case 0:
				System.out.println(" ");
				System.out.print("Hasta pronto");
				System.out.println(" ");
				break;
			case 1:
				System.out.println(" ");
				CrearUsuario();
				System.out.println(" ");
				break;
			case 2:
				System.out.println(" ");
				AbonarDinero();
				System.out.println(" ");
				break;
			case 3:
				System.out.println(" ");
				DescuentoViaje();
				System.out.println(" ");
				break;
			case 4:
				System.out.println(" ");
				ConsultarSaldo();
				System.out.println(" ");
				break;
			case 5:
				System.out.println(" ");
				CambiarEstado();
				System.out.println(" ");
				break;
			default:
				System.out.println(" ");
				System.out.println("Ingrese opcion valida");
				System.out.println(" ");
				break;	
			}
		}while (op!=0);
		
	}
	

	public static void CrearUsuario() throws InterruptedException{
		if(ultimo<T.length) {
			System.out.println("\nNueva tarjeta\n ");

			T[ultimo]=new Tarjeta_Ej1();
			
			T[ultimo].setNro_tarjeta(nro_t);
			nro_t++;
			int tipo;
			do {
				System.out.print("Tipo de usuario -> 1.-Comun / 2.-TNE / 3.-Bip \nIngrese numero: ");
				tipo= sc.nextInt();
				if(tipo==1||tipo==2||tipo==3){
					T[ultimo].setTipo_usuario(tipo);
				}
				else {
					System.out.println("Ingrese opcion valida");
					Thread.sleep(2000);
				}
				
			}while (tipo!=1&&tipo!=2&&tipo!=3);
			
			System.out.print("Monto a recargar: ");
			T[ultimo].setSaldo(sc.nextInt());
			
			T[ultimo].setEstado_tarjeta(true);
			
			System.out.println("\n");
			ultimo++;
		}
		else {
			System.out.println("\nYa ingreso el amximo de tarjrtas");
			Thread.sleep(2000);
		}
	}
	
	public static void AbonarDinero() throws InterruptedException{
		int usuario=SeleccionarUsuario();
		int saldo;
		if (usuario>0) {
			usuario--;
			ImprimirUsuario(usuario);
			System.out.print("Ingrese cantidad a abonar: ");
			saldo=T[usuario].getSaldo()+sc.nextInt();
			T[usuario].setSaldo(saldo);
			ImprimirUsuario(usuario);
		}
		
		else {
			System.out.println("No hay Tarjetas ingresadas");
			Thread.sleep(2000);
		}
	}
	
	private static void DescuentoViaje() throws InterruptedException {
		int usuario=SeleccionarUsuario();
		int pasajeC=1000;
		int pasajeT=200;
		int pasajeB=700;
		if (usuario>0) {
			usuario--;
			ImprimirUsuario(usuario);
			if(T[usuario].getTipo_usuario()==1) {
				if((T[usuario].getSaldo()-pasajeC)>=0) {
					T[usuario].setSaldo(T[usuario].getSaldo()-pasajeC);
					ImprimirUsuario(usuario);
				}
				else {
					System.out.println("Saldo insuficiente...!!!");
					Thread.sleep(2000);
				}
			}
			else if(T[usuario].getTipo_usuario()==2) {
				if((T[usuario].getSaldo()-pasajeT)>=0) {
					T[usuario].setSaldo(T[usuario].getSaldo()-pasajeT);
					ImprimirUsuario(usuario);
				}
				else {
					System.out.println("Saldo insuficiente...!!!");
					Thread.sleep(2000);
				}
			}
			else {
				if((T[usuario].getSaldo()-pasajeB)>=0) {
					T[usuario].setSaldo(T[usuario].getSaldo()-pasajeB);
					ImprimirUsuario(usuario);
				}
				else {
					System.out.println("Saldo insuficiente...!!!");
					Thread.sleep(2000);
				}
			}
		}
		
		else {
			System.out.println("No hay Tarjetas ingresadas");
			Thread.sleep(2000);
		}
		
	}
	
	private static void ConsultarSaldo() throws InterruptedException {
		int usuario=SeleccionarUsuario();
		if (usuario>0) {
			usuario--;
			ImprimirUsuario(usuario);
		}
		
		else {
			System.out.println("No hay Tarjetas ingresadas");
			Thread.sleep(2000);
		}
		
	}

	private static void CambiarEstado() throws InterruptedException {
		int usuario=SeleccionarUsuario();
		if (usuario>0) {
			usuario--;
			ImprimirUsuario(usuario);
			if(T[usuario].isEstado_tarjeta()) {
				T[usuario].setEstado_tarjeta(false);
			}
			else {
				T[usuario].setEstado_tarjeta(true);
			}
			ImprimirUsuario(usuario);
		}
		
		else {
			System.out.println("No hay Tarjetas ingresadas");
			Thread.sleep(2000);
		}
	
		
	}
	
	
	public static int SeleccionarUsuario() throws InterruptedException{
		int usuario;
		if(ultimo>0) {
			System.out.println("Tarjetas ingresadas al sistema: \n");
			for(int i=0;i<ultimo;i++){
				System.out.println((i+1)+".- "+T[i].getNro_tarjeta());
			}
			do {
				System.out.print("\nSeleccione un nro de tarjeta del 1 al "+ultimo+": ");
				usuario=sc.nextInt();
	
				if(usuario<0||usuario>ultimo) {
					System.out.println("Ingrese opcion valida");
					Thread.sleep(2000);
				}
			}while(usuario<0||usuario>ultimo);
			return usuario;
		}
		
		else {
			return 0;
		}
		
	}
	
	public static void ImprimirUsuario(int usuario) throws InterruptedException {
		System.out.println("\nUsuario seleccionado: ");
		System.out.println("Nro_Tarjeta: "+T[usuario].getNro_tarjeta());
		if(T[usuario].getTipo_usuario()==1) {
			System.out.println("Tipo_usuario: Comun");
		}
		else if(T[usuario].getTipo_usuario()==2) {
			System.out.println("Tipo_usuario: TNE");
		}
		else {
			System.out.println("Tipo_usuario: Bip");
		}
		System.out.println("Saldo: $"+T[usuario].getSaldo());
		if(T[usuario].isEstado_tarjeta()) {
			System.out.println("Estado: Tarjeta activa\n");
		}
		else {
			System.out.println("Estado: Tarjeta inactiva\n");
		}
		Thread.sleep(2000);
	}

}
