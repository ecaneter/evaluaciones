package Tarea02;

public class Persona_Ej4 {
	
	public static void main(String[] args) {

		Privado_Ej4 eprivado=new Privado_Ej4();
		Publico_Ej4 epublico=new Publico_Ej4();
		
		epublico.setRut("152423566");
		epublico.setNombre("Fernando");
		epublico.setApellidos("Mellado Salinas");
		epublico.setDireccion("Los Laureles 45");
		epublico.setTelefono(945281947);
		epublico.setSueldo(780000);
		epublico.setMunicipalidad("Municipalidad de los Alamos");
		epublico.setDepartamento("Administrativo");
		
		eprivado.setRut("152423566");
		eprivado.setNombre("Fernando");
		eprivado.setApellidos("Mellado Salinas");
		eprivado.setDireccion("Los Laureles 45");
		eprivado.setTelefono(945281947);
		eprivado.setSueldo(780000);
		eprivado.setComuna("Municipalidad de los Alamos");
		eprivado.setEmpresa("");
		
		System.out.println("Empleado Publico: ");
		System.out.println("Rut: "+epublico.getRut());
		System.out.println("Nombre: "+epublico.getNombre());
		System.out.println("Apellidos: "+epublico.getApellidos());
		System.out.println("Direccion: "+epublico.getDireccion());
		System.out.println("Telefono: "+epublico.getTelefono());
		System.out.println("Sueldo: "+epublico.getSueldo());
		System.out.println("Municipalidad: "+epublico.getMunicipalidad());
		System.out.println("Departamento: "+epublico.getDepartamento());
		
		System.out.println("Empleado Privado: ");
		System.out.println("Rut: "+eprivado.getRut());
		System.out.println("Nombre: "+eprivado.getNombre());
		System.out.println("Apellidos: "+eprivado.getApellidos());
		System.out.println("Direccion: "+eprivado.getDireccion());
		System.out.println("Telefono: "+eprivado.getTelefono());
		System.out.println("Sueldo: "+eprivado.getSueldo());
		System.out.println("Comuna: "+eprivado.getComuna());
		System.out.println("Empresa: "+eprivado.getEmpresa());
		
	}		
}
