package Tarea02;

public class Privado_Ej4 extends Empleado_Ej4{

	private String comuna;
	private String empresa;
	
	public Privado_Ej4() {
	}

	public Privado_Ej4(String comuna, String empresa) {
		this.comuna = comuna;
		this.empresa = empresa;
	}

	public String getComuna() {
		return comuna;
	}

	public void setComuna(String comuna) {
		this.comuna = comuna;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	
}
