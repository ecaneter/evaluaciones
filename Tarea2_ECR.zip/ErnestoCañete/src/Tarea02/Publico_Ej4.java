package Tarea02;

public class Publico_Ej4 extends Empleado_Ej4{
	
	private String municipalidad;
	private String departamento;
	
	public Publico_Ej4() {
	}

	public Publico_Ej4(String municipalidad, String departamento) {
		this.municipalidad = municipalidad;
		this.departamento = departamento;
	}

	public String getMunicipalidad() {
		return municipalidad;
	}

	public void setMunicipalidad(String municipalidad) {
		this.municipalidad = municipalidad;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

}
