package Tarea02;

public class Empleado_Ej2 {
	
	private String rut;
	private String cargo;
	private String nombre;
	private String apellidop;
	private String apellidom;
	private String direccion;
	private int fono;
	private String Email;
	
	public Empleado_Ej2() {
		super();
	}

	public Empleado_Ej2(String rut, String cargo, String nombre, String apellidop, String apellidom) {
		super();
		this.rut = rut;
		this.cargo = cargo;
		this.nombre = nombre;
		this.apellidop = apellidop;
		this.apellidom = apellidom;
	}

	public Empleado_Ej2(String rut, String apellidop, String apellidom, String direccion, int fono, String email) {
		super();
		this.rut = rut;
		this.apellidop = apellidop;
		this.apellidom = apellidom;
		this.direccion = direccion;
		this.fono = fono;
		Email = email;
	}
	

}
