package Tarea02;

public class Tarjeta_Ej1 {
	
	private int nro_tarjeta; 
	private int tipo_usuario;
	private int saldo;
	private boolean estado_tarjeta;
	
	public Tarjeta_Ej1() {
	}

	public Tarjeta_Ej1(int nro_tarjeta, int tipo_usuario, int saldo, boolean estado_tarjeta) {
		this.nro_tarjeta = nro_tarjeta;
		this.tipo_usuario = tipo_usuario;
		this.saldo = saldo;
		this.estado_tarjeta = estado_tarjeta;
	}

	public int getNro_tarjeta() {
		return nro_tarjeta;
	}

	public void setNro_tarjeta(int nro_tarjeta) {
		this.nro_tarjeta = nro_tarjeta;
	}

	public int getTipo_usuario() {
		return tipo_usuario;
	}

	public void setTipo_usuario(int tipo_usuario) {
		this.tipo_usuario = tipo_usuario;
	}

	public int getSaldo() {
		return saldo;
	}

	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}

	public boolean isEstado_tarjeta() {
		return estado_tarjeta;
	}

	public void setEstado_tarjeta(boolean estado_tarjeta) {
		this.estado_tarjeta = estado_tarjeta;
	} 
	
}
